function iniciarSesion(event) {
    event.preventDefault();

    const correo = document.getElementById('loginCorreo').value;
    const password = document.getElementById('loginPassword').value;

    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || {};

    // Validar que el correo exista y coincidan las credenciales
    const usuario = Object.values(usuarios).find(user => user.correo === correo);
    if (!usuario || usuario.password !== password) {
        alert("Correo o contraseña incorrectos.");
        return;
    }

    // Cambiar botón a código de estudiante y redirigir
    const codigoEstudiante = Object.keys(usuarios).find(key => usuarios[key].correo === correo);
    alert("Inicio de sesión exitoso.");
    iniciarSesionAutomatico(codigoEstudiante);
}
window.iniciarSesion = iniciarSesion;