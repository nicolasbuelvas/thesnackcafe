function registrarUsuario(event) {
    event.preventDefault();

    const correo = document.getElementById('registroCorreo').value;
    const codigoEstudiante = document.getElementById('registroCodigo').value;
    const password = document.getElementById('registroPassword').value;
    const passwordRepeat = document.getElementById('registroPasswordRepeat').value;

    // Validar correo institucional
    const regexCorreo = /^[a-zA-Z0-9._%+-]+@u\.icesi\.edu\.co$/;
    if (!regexCorreo.test(correo)) {
        alert("El correo debe tener el formato ...@u.icesi.edu.co.");
        return;
    }

    // Validar código de estudiante (debe comenzar con 'A' seguido de 8 números)
    const regexCodigo = /^A\d{8}$/;
    if (!regexCodigo.test(codigoEstudiante)) {
        alert("El código de estudiante debe empezar con 'A' seguido de 8 números.");
        return;
    }

    // Verificar si las contraseñas coinciden
    if (password !== passwordRepeat) {
        alert("Las contraseñas no coinciden.");
        return;
    }

    // Obtener usuarios registrados desde localStorage
    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || {};

    // Comprobar si el usuario ya está registrado
    if (usuarios[codigoEstudiante]) {
        alert("El usuario ya está registrado.");
        return;
    }

    // Guardar nuevo usuario en localStorage
    usuarios[codigoEstudiante] = { correo, password };
    localStorage.setItem('usuarios', JSON.stringify(usuarios));

    // Iniciar sesión automáticamente y cambiar el botón
    iniciarSesionAutomatico(codigoEstudiante);
    alert("Usuario registrado exitosamente.");
}

// Función para iniciar sesión automáticamente después del registro
function iniciarSesionAutomatico(codigoEstudiante) {
    // Cambiar el botón de "Iniciar sesión" al código de estudiante
    const botonSesion = document.querySelector('.opciones-usuario a');
    botonSesion.innerText = codigoEstudiante;
    botonSesion.onclick = () => window.location.href = 'perfil.html';

    // Redirigir automáticamente al perfil (opcional, si deseas redirigir)
    // window.location.href = 'perfil.html';
}

// Asignar la función al objeto global window
window.registrarUsuario = registrarUsuario;