function seleccionarPedido(tipo) {
    console.log("Pedido seleccionado: " + tipo);
    // Aquí agregamos la lógica de pedido, ya sea para pedir en tienda o recoger
}

// Asignar la función al objeto global window
window.seleccionarPedido = seleccionarPedido;